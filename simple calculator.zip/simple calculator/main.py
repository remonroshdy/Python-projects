# This is a sample Python script calculator

from logo import logo
print(logo)

def calculator():
    def add(num1,num2):
        return num1 + num2

    def multiply(num1,num2):
        return num1 * num2

    def subtract(num1,num2):
        return num1 - num2

    def division(num1,num2):
        return num1 / num2

    operations = {
        "+": add,
        "*": multiply,
        "-": subtract,
        "/": division,
    }

    num1 = int(input("Enter first number "))

    for sym in operations:
        print(sym)

    cont = True

    while cont:

        symb = input("choose asymbol ")

        num2 = int(input("Enter next number "))

        # call my function

        print(operations[symb](num1,num2))

        myfunction = operations[symb]

        ans = myfunction(num1,num2)

        print(f" {num1} {symb}  { num2} =  { ans}" )

        if input("if you  want to continue using previous result type  y or n ")== "y":
            num1 = ans
        else:
            cont = False
            calculator()
calculator()