import replit
from replit import clear
# Auction program
from art import logo
print(logo)
def highest_bid(mydictionary):
    max = 0
    winner = ""
    for item in my_auction:
        if my_auction[item] > max:
            max = my_auction[item]
            winner = item

    print(f"The winner is {winner} and its bidding amount is {max}")

my_auction = {}

print("Welcome to the Auction Program")
ans = True
while ans:

    name = input(" what is your name ")
    bid_amt = int(input(" how much you bid ?"))

    my_auction[name] = bid_amt

    resp = input(" Are there are more users  True, False?")
    clear()

    if resp == "False":
        highest_bid(my_auction)
        ans = False




